<?php

namespace App\Http\Controllers;

use App\GlobalServices\ResponseService;
use App\Models\Order;
use Illuminate\Http\Request;

class ApiOrderController extends Controller
{

    protected $response;
    public function __construct(ResponseService $response)
    {
        $this->response = $response;
    }



    public function orderSubmit(Request $request){
        try{
            dd($request->all());
            $order = new Order();
            $order->order_code = rand(0, 99999);
        }catch(\Exception $e){
            return $this->response->responseError($e->getMessage());
        }
    }
}
